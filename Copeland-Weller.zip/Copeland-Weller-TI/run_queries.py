import pyodbc 
import pandas as pd
import matplotlib.pyplot as plt

products_file = open('data/products.sql')
products_sql = products_file.read()

locations_file = open('data/locations.sql')
locations_sql = locations_file.read()

customerdemographics_file = open('data/customerdemographics.sql')
customerdemographics_sql = customerdemographics_file.read()

customerpurchasehistory_file = open('data/customerpurchasehistory.sql')
customerpurchasehistory_sql = customerpurchasehistory_file.read()

server = 'tcp:localhost,1433' 
username = 'SA' 
password = 'YourStrong@Passw0rd' 

cnxn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';ENCRYPT=no;UID='+username+';PWD='+ password+';TrustServerCertificate=yes')
crsr = cnxn.cursor()

df1 = pd.read_sql("SELECT *   FROM INFORMATION_SCHEMA.TABLES", cnxn)
print(df1)

crsr.execute(products_sql)
crsr.execute(locations_sql)
crsr.execute(customerdemographics_sql)
crsr.execute(customerpurchasehistory_sql)

df3 = pd.read_sql("SELECT *  FROM INFORMATION_SCHEMA.TABLES", cnxn)
print(df3)


# Q1
products_purchases_by_month_df = pd.read_sql("""
                                                SELECT
                                                    DATENAME(MONTH, DATEADD(MONTH, MONTH(cph.PurchaseDate), -1)) as PurchaseMonthName, 
                                                    MONTH(cph.PurchaseDate)as PurchaseMonth,
                                                    p.ProductName, 
                                                    COUNT(cph.ProductID) as PurchaseCountPerMonth, 
                                                    SUM(cph.Quantity) as PurchaseQuantityPerMonth 
                                                 FROM dbo.CustomerPurchaseHistory cph 
                                                join dbo.Product p on p.ProductID = cph.ProductId  
                                                group by MONTH(cph.PurchaseDate), p.ProductName""", cnxn)
print(products_purchases_by_month_df)
products_purchases_by_month_df.to_csv('results/Q1_products_purchases_by_month.csv')



total_purchases_YTD_df = pd.read_sql("""
                                        SELECT 
                                        MONTH(cph.PurchaseDate) as PurchaseMonth, 
                                        SUM(
                                            CASE WHEN cph.Quantity is null then 0 else cph.quantity end
                                        ) as PurchaseQuantityPerMonth 
                                        FROM 
                                        dbo.CustomerPurchaseHistory cph 
                                        group by 
                                        MONTH(cph.PurchaseDate)
                                        order by 
                                        MONTH(cph.PurchaseDate)
                                                """, cnxn)
print(total_purchases_YTD_df)

total_purchases_YTD_df.plot(x ='PurchaseMonth', y='PurchaseQuantityPerMonth', kind='line')
plt.savefig('images/total_purchases_quantity_YTD.png')

total_purchases_count_YTD_df = pd.read_sql(""" 
                                                SELECT
                                                    MONTH(cph.PurchaseDate) as PurchaseMonth,
                                                    COUNT(cph.PurchaseDate) as PurchaseCountPerMonth 
                                                FROM dbo.CustomerPurchaseHistory cph 
                                                group by MONTH(cph.PurchaseDate)
                                     order by MONTH(cph.PurchaseDate)
                                                """, cnxn)
print(total_purchases_count_YTD_df)

total_purchases_count_YTD_df.plot(x ='PurchaseMonth', y='PurchaseCountPerMonth', kind='line')
plt.savefig('images/total_purchases_count_YTD.png')


# Q2
avg_age_customer_by_product_df = pd.read_sql("""
                                                SELECT 
                                                    p.ProductName, 
                                                    AVG(c.Age) as AverageCustomerAge 
                                                 FROM dbo.CustomerPurchaseHistory cph 
                                                join dbo.CustomerDemographics c on c.CustomerID = cph.Customer 
                                                join dbo.Product p on p.ProductID = cph.ProductId 
                                                group by p.ProductName""", cnxn)
print(avg_age_customer_by_product_df)
avg_age_customer_by_product_df.to_csv('results/Q2_avg_age_customer_by_product.csv')


# Q3
most_purchased_by_age_group_df = pd.read_sql("""
                                            with age_groups as (
                                                SELECT 
                                                    p.ProductName, 
                                                    cph.Quantity,
                                                    c.age,
                                                    CASE 
                                                        WHEN c.Age between 18 and 28 THEN '18-28'
                                                        WHEN c.Age between 29 and 38 THEN '29-38'
                                                        WHEN c.Age between 39 and 48 THEN '39-48'
                                                        WHEN c.Age between 49 and 58 THEN '49-58'
                                                        WHEN c.Age between 59 and 68 THEN '59-68'
                                                        WHEN c.Age between 69 and 78 THEN '69-78'
                                                        WHEN c.Age between 79 and 88 THEN '79-88'
                                                        WHEN c.Age between 89 and 100 THEN '89-100'
                                                    END AS AgeGroup
                                                 FROM dbo.CustomerPurchaseHistory cph 
                                                join dbo.CustomerDemographics c on c.CustomerID = cph.Customer 
                                                join dbo.Product p on p.ProductID = cph.ProductId),
                                             
                                                product_sales_per_age_group as (
                                                SELECT
                                                    ProductName, 
                                                    SUM(Quantity) as QuantityPurchasedTotal, 
                                                    AgeGroup, 
                                                    row_number() over (partition by AgeGroup order by SUM(Quantity) desc) as row_num
                                                 FROM age_groups 
                                                group by AgeGroup, ProductName)

                                            SELECT 
                                                AgeGroup, 
                                                ProductName, 
                                                QuantityPurchasedTotal
                                            FROM product_sales_per_age_group 
                                            where row_num = 1
                                             order by AgeGroup
                                              """, cnxn)
print(most_purchased_by_age_group_df)
most_purchased_by_age_group_df.to_csv('results/Q3_most_purchased_by_age_group.csv')

bar_plot = most_purchased_by_age_group_df.plot(x='AgeGroup', y='QuantityPurchasedTotal', kind='bar', figsize=(15, 15))
bar_plot.bar_label(bar_plot.containers[0], labels=most_purchased_by_age_group_df['ProductName'])
plt.savefig('images/most_purchased_by_age_group.png')


# Q4
repeat_customers_df = pd.read_sql("""
                                            with repeat_customers as (
                                                SELECT c.CustomerId, 
                                                CASE WHEN COUNT(c.CustomerId) > 1 then 'True' else 'False' end as is_repeat_customer 
                                                FROM dbo.CustomerPurchaseHistory cph 
                                                join dbo.CustomerDemographics c on c.CustomerID = cph.Customer 
                                                group by c.CustomerId, cph.PurchaseDate)
                                            
                                            SELECT 
                                                * 
                                            FROM repeat_customers 
                                            where is_repeat_customer = 'True' """, cnxn)
print(repeat_customers_df)
repeat_customers_df.to_csv('results/Q4_repeat_customers.csv')

repeat_vs_new_customers_sales_df = pd.read_sql("""
                                            with repeat_customers as (
                                                SELECT c.CustomerId, 
                                                CASE WHEN COUNT(c.CustomerId) > 1 then 'True' else 'False' end as is_repeat_customer
                                                FROM dbo.CustomerPurchaseHistory cph 
                                                join dbo.CustomerDemographics c on c.CustomerID = cph.Customer 
                                                group by c.CustomerId, cph.PurchaseDate)
                                            
                                            SELECT 
                                                CASE WHEN is_repeat_customer = 'True' then 'RepeatCustomer' else 'NewCustomer' end as CustomerLabel,
                                                SUM(cph.Quantity) as CustomerTypeSales
                                            FROM repeat_customers 
                                            join dbo.CustomerPurchaseHistory cph on repeat_customers.CustomerID = cph.Customer 
                                            group by is_repeat_customer """, cnxn)
print(repeat_vs_new_customers_sales_df)
# repeat_vs_new_customers_df
repeat_vs_new_customers_sales_df.set_index('CustomerLabel').plot.pie(y='CustomerTypeSales', autopct="%.2f", figsize=(10, 10))
plt.savefig('images/customer_type_sales.png')



# Q5


products_sma_df = pd.read_sql("""
                                    with product_sales_by_month as (
                                             SELECT 
                                     MONTH(cph.PurchaseDate) as PurchaseMonth, 
                                     p.ProductName, 
                                     COUNT(cph.ProductID) as PurchaseCount, 
                                     SUM(cph.Quantity) as QuantityPerMonth   
                                     FROM dbo.CustomerPurchaseHistory cph 
                                     join dbo.Product p on p.ProductID = cph.ProductId  
                                     group by MONTH(cph.PurchaseDate), p.ProductName),
                              
                              months_todate as (
                                        select 
                                            1 as month 
                                        union all 
                                        select 
                                            2 as month 
                                        union all 
                                        select 
                                            3 as month 
                                        union all 
                                        select 
                                            4 as month 
                                        union all 
                                        select 
                                            5 as month 
                                        union all 
                                        select 
                                            6 as month
                                        ) 


                                     
                                     SELECT
                                        months_todate.month, ProductName, QuantityPerMonth,
                                        AVG(CASE WHEN QuantityPerMonth is null then 0 else QuantityPerMonth end) OVER (ORDER BY months_todate.month ROWS BETWEEN 1 PRECEDING AND CURRENT ROW) as SMA
                                        FROM months_todate 
                              left join  product_sales_by_month
                                        ON months_todate.month = product_sales_by_month.PurchaseMonth
                              
                             
                              
                                     
                                             """, cnxn)
print(products_sma_df)
products_sma_df.to_csv('results/Q5_sma.csv')


best_selling_products_sma_df = pd.read_sql("""
                                                                 with product_sales_by_month as (
                                             SELECT 
                                     MONTH(cph.PurchaseDate) as PurchaseMonth, 
                                     p.ProductName, 
                                     COUNT(cph.ProductID) as PurchaseCount, 
                                     SUM(cph.Quantity) as QuantityPerMonth   
                                     FROM dbo.CustomerPurchaseHistory cph 
                                     join dbo.Product p on p.ProductID = cph.ProductId  
                                     group by MONTH(cph.PurchaseDate), p.ProductName),


                                   months_todate as (
                                        select 
                                            1 as month 
                                        union all 
                                        select 
                                            2 as month 
                                        union all 
                                        select 
                                            3 as month 
                                        union all 
                                        select 
                                            4 as month 
                                        union all 
                                        select 
                                            5 as month 
                                        union all 
                                        select 
                                            6 as month
                                        ),

                                        single_product as (
                                             SELECT
                                        PurchaseMonth,
                                        QuantityPerMonth
                                        FROM product_sales_by_month
                                        where ProductName = 'ProductName89'
       
                                        )
                                            
                                          SELECT
                                        months_todate.month as month,
                                        CASE WHEN QuantityPerMonth is null then 0 else QuantityPerMonth end as QuantityPerMonth,
                                        AVG(CASE WHEN QuantityPerMonth is null then 0 else QuantityPerMonth end) OVER (ORDER BY month ROWS BETWEEN 1 PRECEDING AND CURRENT ROW) as SMA
                                        FROM months_todate 
                              LEFT JOIN  single_product
                                        ON months_todate.month = single_product.PurchaseMonth
                                     
                                             """, cnxn)
print(best_selling_products_sma_df)

best_selling_products_sma_df.set_index('month').plot()
plt.savefig('images/best_selling_products_sma.png')

least_selling_products_sma_df = pd.read_sql("""
                                    with product_sales_by_month as (
                                             SELECT 
                                     MONTH(cph.PurchaseDate) as PurchaseMonth, 
                                     p.ProductName, 
                                     COUNT(cph.ProductID) as PurchaseCount, 
                                     SUM(cph.Quantity) as QuantityPerMonth   
                                     FROM dbo.CustomerPurchaseHistory cph 
                                     join dbo.Product p on p.ProductID = cph.ProductId  
                                     group by MONTH(cph.PurchaseDate), p.ProductName),


                                   months_todate as (
                                        select 
                                            1 as month 
                                        union all 
                                        select 
                                            2 as month 
                                        union all 
                                        select 
                                            3 as month 
                                        union all 
                                        select 
                                            4 as month 
                                        union all 
                                        select 
                                            5 as month 
                                        union all 
                                        select 
                                            6 as month
                                        ),

                                        single_product as (
                                             SELECT
                                        PurchaseMonth,
                                        QuantityPerMonth
                                        FROM product_sales_by_month
                                        where ProductName = 'ProductName71'
       
                                        )
                                            
                                          SELECT
                                        months_todate.month as month,
                                        CASE WHEN QuantityPerMonth is null then 0 else QuantityPerMonth end as QuantityPerMonth,
                                        AVG(CASE WHEN QuantityPerMonth is null then 0 else QuantityPerMonth end) OVER (ORDER BY month ROWS BETWEEN 1 PRECEDING AND CURRENT ROW) as SMA
                                        FROM months_todate 
                              LEFT JOIN  single_product
                                        ON months_todate.month = single_product.PurchaseMonth
                                          
                                            
                                           
                                             """, cnxn)
print(least_selling_products_sma_df)
least_selling_products_sma_df.to_csv('least.csv')


least_selling_products_sma_df.set_index('month').plot()
plt.savefig('images/least_selling_products_sma.png')

                                        # AVG(QuantityPerMonth) OVER (ORDER BY PurchaseMonth ROWS BETWEEN 1 PRECEDING AND CURRENT ROW) as SMA



# Q6
nevada_locations_df = pd.read_sql("""
                                    DECLARE @g geography = geography::STGeomFromText('POLYGON ((-120 42, -120 39, -114.6 35, -114.75 36.2, -114.1 36.1, -114.1 42, -120 42))', 4326); 
                                    SELECT 
                                            LocationID, 
                                            LocationName, 
                                            City
                                    FROM dbo.Location
                                    where  @g.STContains(Coordinates) = 'True'
                           """, cnxn)
print(nevada_locations_df)
nevada_locations_df.to_csv('results/Q6_nevada_locations.csv')

crsr.close()
cnxn.close()