with product_sales_by_month as (
  SELECT 
    MONTH(cph.PurchaseDate) as PurchaseMonth, 
    p.ProductName, 
    COUNT(cph.ProductID) as PurchaseCount, 
    SUM(cph.Quantity) as QuantityPerMonth 
  FROM 
    dbo.CustomerPurchaseHistory cph 
    join dbo.Product p on p.ProductID = cph.ProductId 
  group by 
    MONTH(cph.PurchaseDate), 
    p.ProductName
) 
SELECT 
  PurchaseMonth, 
  ProductName, 
  QuantityPerMonth, 
  AVG(QuantityPerMonth) OVER (
    ORDER BY 
      PurchaseMonth ROWS BETWEEN 1 PRECEDING 
      AND CURRENT ROW
  ) as SMA 
FROM 
  product_sales_by_month

                              