SELECT 
  p.ProductName, 
  AVG(c.Age) as AverageCustomerAge 
FROM 
  dbo.CustomerPurchaseHistory cph 
  join dbo.CustomerDemographics c on c.CustomerID = cph.Customer 
  join dbo.Product p on p.ProductID = cph.ProductId 
group by 
  p.ProductName
