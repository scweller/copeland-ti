with age_groups as (
  SELECT 
    p.ProductName, 
    cph.Quantity, 
    c.age, 
    CASE WHEN c.Age between 18 
    and 28 THEN '18-28' WHEN c.Age between 29 
    and 38 THEN '29-38' WHEN c.Age between 39 
    and 48 THEN '39-48' WHEN c.Age between 49 
    and 58 THEN '49-58' WHEN c.Age between 59 
    and 68 THEN '59-68' WHEN c.Age between 69 
    and 78 THEN '69-78' WHEN c.Age between 79 
    and 88 THEN '79-88' WHEN c.Age between 89 
    and 100 THEN '89-100' END AS AgeGroup 
  FROM 
    dbo.CustomerPurchaseHistory cph 
    join dbo.CustomerDemographics c on c.CustomerID = cph.Customer 
    join dbo.Product p on p.ProductID = cph.ProductId
), 
product_sales_per_age_group as (
  SELECT 
    ProductName, 
    SUM(Quantity) as QuantityPurchasedTotal, 
    AgeGroup, 
    row_number() over (
      partition by AgeGroup 
      order by 
        SUM(Quantity) desc
    ) as row_num 
  FROM 
    age_groups 
  group by 
    AgeGroup, 
    ProductName
) 
SELECT 
  AgeGroup, 
  ProductName, 
  QuantityPurchasedTotal 
FROM 
  product_sales_per_age_group 
where 
  row_num = 1 
order by 
  AgeGroup
