with repeat_customers as (
  SELECT 
    c.CustomerId, 
    CASE WHEN COUNT(c.CustomerId) > 1 then 'True' else 'False' end as is_repeat_customer 
  FROM 
    dbo.CustomerPurchaseHistory cph 
    join dbo.CustomerDemographics c on c.CustomerID = cph.Customer 
  group by 
    c.CustomerId, 
    cph.PurchaseDate
) 
SELECT 
  * 
FROM 
  repeat_customers 
where 
  is_repeat_customer = 'True'
