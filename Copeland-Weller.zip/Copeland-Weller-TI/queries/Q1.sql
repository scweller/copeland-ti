SELECT 
  DATENAME(
    MONTH, 
    DATEADD(
      MONTH, 
      MONTH(cph.PurchaseDate), 
      -1
    )
  ) as PurchaseMonthName, 
  MONTH(cph.PurchaseDate) as PurchaseMonth, 
  p.ProductName, 
  COUNT(cph.ProductID) as PurchaseCountPerMonth, 
  SUM(cph.Quantity) as PurchaseQuantityPerMonth 
FROM 
  dbo.CustomerPurchaseHistory cph 
  join dbo.Product p on p.ProductID = cph.ProductId 
group by 
  MONTH(cph.PurchaseDate), 
  p.ProductName
