DECLARE @g geography = geography :: STGeomFromText(
  'POLYGON ((-120 42, -120 39, -114.6 35, -114.75 36.2, -114.1 36.1, -114.1 42, -120 42))', 
  4326
);
SELECT 
  LocationID, 
  LocationName, 
  City 
FROM 
  dbo.Location 
where 
  @g.STContains(Coordinates) = 'True'
