Copeland Take Home Assignment
Samantha Weller - August 2023



Below walks through the files in this repo:

CopelandDataVisualizations-Weller.pdf
	This a simple powerpoint saved to a pdf showing a few data visualizations. 

data/
    This contains the sample sql given for the take home assignment. I split it into four smaller files for personal ease of inspecting the sql.

results/
    This contains csv output files of the 6 sql queries that are in the run_queries.py script. Each file is prefixes with Q{#} to correspond with the question in the take home. 

images/
    Images created from data visualizations. These are utilized in the attached pptx(as pdf) export. 

queries/ 
    Pulled out each sql statement answering the take home questions to individual file. This is just for ease of readability and these files are not references in the run_queries.py. The filename corresponds to the question number.

run_queries.py
    A python script using pyodbc, pandas, matplotlib to run the queries and save the results locally and create visualizations. Along with the queries to complete the assignment, other queries are specifically for the data visualizations.







Input Question Answers: 
1. What enhancements would you make to this?
    I would add in columns that tell me about the data ingestion behavior, when it was updated/created/modified(ex: updated_at, created_at). This allows us to track health of the data, or if data changes occur such as a customer modifying there order from sale to fulfillment. 

2. Can you provide any other metrics that would be useful to the business. 
        - Compare repeat to new customers
        - Average Order Value, per customer and overall, how is this trending?
        - Customer Lifetime Value, who are the high value customers and who are the customers with opportunities to target?


Other Notes: 
 For question 5, I did a simple moving average calc which will not give us an exact number for July but will give us a general trend to follow if plotted. 
 Reference: https://towardsdatascience.com/how-to-conduct-time-series-forecasting-in-sql-with-moving-averages-fd5e6f2a456


